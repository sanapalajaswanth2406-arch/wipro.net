﻿using System;
using System.Collections;

class Employee
{
    public int EmployeeID;
    public string EmployeeName;
    public double Salary;

    public Employee(int id, string name, double salary)
    {
        EmployeeID = id;
        EmployeeName = name;
        Salary = salary;
    }
}

class EmployeeDAL
{
    ArrayList empList = new ArrayList();

    public bool AddEmployee(Employee e)
    {
        empList.Add(e);
        return true;
    }

    public bool DeleteEmployee(int id)
    {
        foreach (Employee e in empList)
        {
            if (e.EmployeeID == id)
            {
                empList.Remove(e);
                return true;
            }
        }
        return false;
    }

    public string SearchEmployee(int id)
    {
        foreach (Employee e in empList)
        {
            if (e.EmployeeID == id)
                return e.EmployeeName;
        }
        return null;
    }

    public Employee[] GetAllEmployees()
    {
        Employee[] employees = new Employee[empList.Count];

        for (int i = 0; i < empList.Count; i++)
        {
            employees[i] = (Employee)empList[i];
        }

        return employees;
    }
}

class Program
{
    static void Main()
    {
        EmployeeDAL dal = new EmployeeDAL();
        int choice;

        do
        {
            Console.WriteLine("\n===== Employee Management =====");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2. Search Employee");
            Console.WriteLine("3. Delete Employee");
            Console.WriteLine("4. Display All Employees");
            Console.WriteLine("5. Exit");
            Console.Write("Enter Choice: ");

            choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Enter Employee ID: ");
                    int id = Convert.ToInt32(Console.ReadLine());

                    Console.Write("Enter Employee Name: ");
                    string name = Console.ReadLine();

                    Console.Write("Enter Salary: ");
                    double salary = Convert.ToDouble(Console.ReadLine());

                    dal.AddEmployee(new Employee(id, name, salary));
                    Console.WriteLine("Employee Added Successfully.");
                    break;

                case 2:
                    Console.Write("Enter Employee ID to Search: ");
                    id = Convert.ToInt32(Console.ReadLine());

                    string empName = dal.SearchEmployee(id);

                    if (empName != null)
                        Console.WriteLine("Employee Found: " + empName);
                    else
                        Console.WriteLine("Employee Not Found.");
                    break;

                case 3:
                    Console.Write("Enter Employee ID to Delete: ");
                    id = Convert.ToInt32(Console.ReadLine());

                    if (dal.DeleteEmployee(id))
                        Console.WriteLine("Employee Deleted Successfully.");
                    else
                        Console.WriteLine("Employee Not Found.");
                    break;

                case 4:
                    Employee[] employees = dal.GetAllEmployees();

                    if (employees.Length == 0)
                    {
                        Console.WriteLine("No Employees Available.");
                    }
                    else
                    {
                        Console.WriteLine("\nEmployee List");
                        foreach (Employee e in employees)
                        {
                            Console.WriteLine("ID: " + e.EmployeeID +
                                              "  Name: " + e.EmployeeName +
                                              "  Salary: " + e.Salary);
                        }
                    }
                    break;

                case 5:
                    Console.WriteLine("Thank You!");
                    break;

                default:
                    Console.WriteLine("Invalid Choice.");
                    break;
            }

        } while (choice != 5);
    }
}