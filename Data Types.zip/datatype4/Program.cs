﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter a string: ");
        string str = Console.ReadLine();

        // 1. Reverse
        char[] arr = str.ToCharArray();
        Array.Reverse(arr);
        Console.WriteLine("Reversed String: " + new string(arr));

        // 2. Extract from 2nd position till end
        if (str.Length > 1)
            Console.WriteLine("Substring from 2nd position: " + str.Substring(1));
        else
            Console.WriteLine("String is too short.");

        // 3. Replace a character with '$'
        Console.Write("Enter character to replace: ");
        char ch = Convert.ToChar(Console.ReadLine());

        string replaced = str.Replace(ch, '$');
        Console.WriteLine("After Replacement: " + replaced);

        // 4. Copy string to another variable
        string str2 = String.Copy(str);

        Console.Write("Enter new value for second string: ");
        str2 = Console.ReadLine();

        Console.WriteLine("Original String: " + str);
        Console.WriteLine("Modified Second String: " + str2);
    }
}