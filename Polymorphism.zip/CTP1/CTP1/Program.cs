﻿using System;
class Area
{
    public void CalculateArea(double radius)
    {
        double area = 3.14 * radius * radius;
        Console.WriteLine("Area of the circle = " + area);
    }

    public void CalculateArea(double length, double breadth)
    {
        double area = length * breadth;
        Console.WriteLine("Area of the rectangle = " + area);
    }

    public void CalculateArea(float baseValue, float height)
    {
        float area = baseValue * height * 0.5f;
        Console.WriteLine("Afrea if the triangle = " + area);
    }
}


class Program
{
    static void Main(string[] args)
    {
        Area a = new Area();

        Console.WriteLine("Enter the radius of the circle : ");
        double radius = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Enter the length of the rectangle : ");
        double length = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Enter the breadtg of the rectangle : ");
        double breadth = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Enter the base of the triangle : ");
        float baseValue = Convert.ToSingle(Console.ReadLine());

        Console.WriteLine("Enter the height of the triangle : ");
        float height = Convert.ToSingle(Console.ReadLine());

        Console.WriteLine();

        a.CalculateArea(radius);
        a.CalculateArea(length, breadth);
        a.CalculateArea(baseValue, height);
    }
}