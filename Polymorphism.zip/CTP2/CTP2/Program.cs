﻿using System;

class MathOperations
{
    // Addition
    public int Add(int a, int b)
    {
        return a + b;
    }

    public int Add(int a, int b, int c)
    {
        return a + b + c;
    }

    // Subtraction
    public int Subtract(int a, int b)
    {
        return a - b;
    }

    public int Subtract(int a, int b, int c)
    {
        return a - b - c;
    }

    // Multiplication
    public int Multiply(int a, int b)
    {
        return a * b;
    }

    public int Multiply(int a, int b, int c)
    {
        return a * b * c;
    }

    // Division
    public int Divide(int a, int b)
    {
        return a / b;
    }

    public int Divide(int a, int b, int c)
    {
        return (a / b) / c;
    }
}

class Program
{
    static void Main(string[] args)
    {
        MathOperations obj = new MathOperations();

        Console.WriteLine("Addition:");
        Console.WriteLine("Add(10,20) = " + obj.Add(10, 20));
        Console.WriteLine("Add(10,20,30) = " + obj.Add(10, 20, 30));

        Console.WriteLine("\nSubtraction:");
        Console.WriteLine("Subtract(20,10) = " + obj.Subtract(20, 10));
        Console.WriteLine("Subtract(30,10,5) = " + obj.Subtract(30, 10, 5));

        Console.WriteLine("\nMultiplication:");
        Console.WriteLine("Multiply(5,4) = " + obj.Multiply(5, 4));
        Console.WriteLine("Multiply(2,3,4) = " + obj.Multiply(2, 3, 4));

        Console.WriteLine("\nDivision:");
        Console.WriteLine("Divide(20,5) = " + obj.Divide(20, 5));
        Console.WriteLine("Divide(100,5,2) = " + obj.Divide(100, 5, 2));

        Console.ReadKey();
    }
}