﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter num1: ");
        int num1 = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter num2: ");
        int num2 = Convert.ToInt32(Console.ReadLine());

        num2 = num1++;

        Console.WriteLine("After Post-Increment:"); 
        Console.WriteLine("num1 = " + num1);
        Console.WriteLine("num2 = " + num2);
    }
}
