﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter 1st number: ");
        string num1 = Console.ReadLine();
        Console.Write("Enter 2nd number: ");
        string num2 = Console.ReadLine();
        // Reverse the first number
        char[] arr = num1.ToCharArray();
        Array.Reverse(arr);
        string reversed = new string(arr);
        // Find the position
        int pos = reversed.IndexOf(num2);
        string[] places = { "unit's", "ten's", "hundreds", "thousands" };
        if (pos >= 0 && pos < 4)
            Console.WriteLine(places[pos]);
        else
            Console.WriteLine("not found in first 4 places");
    }
}