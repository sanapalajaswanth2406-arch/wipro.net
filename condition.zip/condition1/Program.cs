﻿using System;

class Program
{
    static void Main()
    {
        for (int i = 0; i < 3; i++)
        {
            Console.Write("Login: ");
            string username = Console.ReadLine();

            Console.Write("Password: ");
            string password = Console.ReadLine();

            if (username == "admin" && password == "1234")
            {
                Console.WriteLine("Access granted");
                return; // Exit the program
            }

            Console.WriteLine("Wrong attempt");
        }

        Console.WriteLine("Rejected");
    }
}
