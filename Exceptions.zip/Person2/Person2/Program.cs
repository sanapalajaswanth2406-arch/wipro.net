﻿using System;

// Custom Exception
class NegativeNumberException : Exception
{
    public NegativeNumberException(string message) : base(message)
    {
    }
}

// Person Class
class Person
{
    private string firstName;
    private string lastName;
    private string emailAddress;
    private DateTime dateOfBirth;

    public Person(string firstName, string lastName, string emailAddress, DateTime dateOfBirth)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAddress = emailAddress;
        this.dateOfBirth = dateOfBirth;
    }

    public string FirstName
    {
        get { return firstName; }
    }

    public string LastName
    {
        get { return lastName; }
    }

    public string Email
    {
        get { return emailAddress; }
    }

    public DateTime DOB
    {
        get { return dateOfBirth; }
    }

    // Read-only Property
    public bool IsAdult
    {
        get
        {
            int age = DateTime.Now.Year - dateOfBirth.Year;

            if (dateOfBirth > DateTime.Now.AddYears(-age))
                age--;

            return age >= 18;
        }
    }

    // Read-only Property
    public bool IsBirthDay
    {
        get
        {
            return (DateTime.Now.Day == dateOfBirth.Day &&
                    DateTime.Now.Month == dateOfBirth.Month);
        }
    }

    // Read-only Property
    public string ScreenName
    {
        get
        {
            return firstName.ToLower() +
                   lastName.ToLower() +
                   dateOfBirth.Day.ToString("00") +
                   dateOfBirth.Month.ToString("00") +
                   dateOfBirth.Year;
        }
    }

    // Read-only Property
    public string SunSign
    {
        get
        {
            int day = dateOfBirth.Day;
            int month = dateOfBirth.Month;

            if ((month == 3 && day >= 21) || (month == 4 && day <= 19))
                return "Aries";
            else if ((month == 4 && day >= 20) || (month == 5 && day <= 20))
                return "Taurus";
            else if ((month == 5 && day >= 21) || (month == 6 && day <= 20))
                return "Gemini";
            else if ((month == 6 && day >= 21) || (month == 7 && day <= 22))
                return "Cancer";
            else if ((month == 7 && day >= 23) || (month == 8 && day <= 22))
                return "Leo";
            else if ((month == 8 && day >= 23) || (month == 9 && day <= 22))
                return "Virgo";
            else if ((month == 9 && day >= 23) || (month == 10 && day <= 22))
                return "Libra";
            else if ((month == 10 && day >= 23) || (month == 11 && day <= 21))
                return "Scorpio";
            else if ((month == 11 && day >= 22) || (month == 12 && day <= 21))
                return "Sagittarius";
            else if ((month == 12 && day >= 22) || (month == 1 && day <= 19))
                return "Capricorn";
            else if ((month == 1 && day >= 20) || (month == 2 && day <= 18))
                return "Aquarius";
            else
                return "Pisces";
        }
    }
}

// Employee Class
class Employee : Person
{
    public double Salary { get; set; }

    public Employee(string firstName, string lastName,
                    string email, DateTime dob,
                    double salary)
        : base(firstName, lastName, email, dob)
    {
        Salary = salary;
    }
}

class Program
{
    static void Main(string[] args)
    {
        try
        {
            Console.Write("Enter First Name: ");
            string fname = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(fname))
                throw new ArgumentException("First Name cannot be empty.");

            foreach (char c in fname)
            {
                if (!char.IsLetter(c))
                    throw new ArgumentException("First Name should contain only alphabets.");
            }

            Console.Write("Enter Last Name: ");
            string lname = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(lname))
                throw new ArgumentException("Last Name cannot be empty.");

            foreach (char c in lname)
            {
                if (!char.IsLetter(c))
                    throw new ArgumentException("Last Name should contain only alphabets.");
            }

            Console.Write("Enter Email Address: ");
            string email = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(email) || !email.Contains("@") || !email.Contains("."))
                throw new ArgumentException("Invalid Email Address.");

            Console.Write("Enter Date of Birth (dd/MM/yyyy): ");
            DateTime dob = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter Salary: ");
            double salary = Convert.ToDouble(Console.ReadLine());

            if (salary < 0)
                throw new NegativeNumberException("Salary cannot be negative.");

            Employee emp = new Employee(fname, lname, email, dob, salary);

            Console.WriteLine("\n========== Employee Details ==========");
            Console.WriteLine("First Name  : " + emp.FirstName);
            Console.WriteLine("Last Name   : " + emp.LastName);
            Console.WriteLine("Email       : " + emp.Email);
            Console.WriteLine("DOB         : " + emp.DOB.ToShortDateString());
            Console.WriteLine("Salary      : " + emp.Salary);
            Console.WriteLine("Is Adult    : " + emp.IsAdult);
            Console.WriteLine("Birthday    : " + emp.IsBirthDay);
            Console.WriteLine("Sun Sign    : " + emp.SunSign);
            Console.WriteLine("Screen Name : " + emp.ScreenName);
        }

        catch (FormatException)
        {
            Console.WriteLine("\nFormatException Caught!");
            Console.WriteLine("Please enter numeric values correctly.");
        }

        catch (ArgumentException ex)
        {
            Console.WriteLine("\nArgumentException Caught!");
            Console.WriteLine(ex.Message);
        }

        catch (NegativeNumberException ex)
        {
            Console.WriteLine("\nNegativeNumberException Caught!");
            Console.WriteLine(ex.Message);
        }

        catch (Exception ex)
        {
            Console.WriteLine("\nException Caught!");
            Console.WriteLine(ex.Message);
        }

        Console.WriteLine("\nPress any key to exit...");
        Console.ReadKey();
    }
}