﻿using System;

// Custom Exception Class
class NegativeNumberException : Exception
{
    public NegativeNumberException(string message) : base(message)
    {
    }
}

class Program
{
    static void Main(string[] args)
    {
        string name;
        int mark1, mark2, mark3;

        try
        {
            Console.Write("Enter Student Name: ");
            name = Console.ReadLine();

            Console.Write("Enter Marks in Subject 1: ");
            mark1 = Convert.ToInt32(Console.ReadLine());
            if (mark1 < 0)
                throw new NegativeNumberException("Marks cannot be negative.");

            Console.Write("Enter Marks in Subject 2: ");
            mark2 = Convert.ToInt32(Console.ReadLine());
            if (mark2 < 0)
                throw new NegativeNumberException("Marks cannot be negative.");

            Console.Write("Enter Marks in Subject 3: ");
            mark3 = Convert.ToInt32(Console.ReadLine());
            if (mark3 < 0)
                throw new NegativeNumberException("Marks cannot be negative.");

            int total = mark1 + mark2 + mark3;
            double average = total / 3.0;

            Console.WriteLine("\nStudent Details");
            Console.WriteLine("---------------------------");
            Console.WriteLine("Name       : " + name);
            Console.WriteLine("Subject 1  : " + mark1);
            Console.WriteLine("Subject 2  : " + mark2);
            Console.WriteLine("Subject 3  : " + mark3);
            Console.WriteLine("Total      : " + total);
            Console.WriteLine("Average    : " + average);
        }
        catch (FormatException)
        {
            Console.WriteLine("\nFormatException Caught!");
            Console.WriteLine("Please enter only integer values for marks.");
        }
        catch (NegativeNumberException ex)
        {
            Console.WriteLine("\nNegativeNumberException Caught!");
            Console.WriteLine(ex.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine("\nError: " + ex.Message);
        }
    }
}