﻿using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        // Specify the file path
        string filePath = @"D:\MyFiles\Sample.txt";

        try
        {
            // Create the directory if it does not exist
            Directory.CreateDirectory(Path.GetDirectoryName(filePath));

            // Create the file and write contents
            StreamWriter writer = new StreamWriter(filePath);

            writer.WriteLine("Welcome to C# File Handling");
            writer.WriteLine("This file is created using StreamWriter.");
            writer.WriteLine("Current Date and Time: " + DateTime.Now);
            writer.WriteLine("File handling is easy in C#.");

            // Save and close the file
            writer.Close();

            Console.WriteLine("File created and contents written successfully.");
            Console.WriteLine("File Location: " + filePath);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }

    }
}